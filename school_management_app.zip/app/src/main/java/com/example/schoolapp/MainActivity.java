package com.example.schoolapp;

public class MainActivity {}